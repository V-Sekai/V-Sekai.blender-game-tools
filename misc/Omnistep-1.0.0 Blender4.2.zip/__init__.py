import bpy
from . import OmniStep

# Register
def register():
	OmniStep.register()

# Unregister
def unregister():
	OmniStep.unregister()
